//
//  AdView.h
//  Fresh8Sdk
//
//  Created by Aram Pamuk on 30/10/2015.
//  Copyright © 2015 Aram Pamuk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Fresh8Sdk/Fresh8AdView.h>
#import <Fresh8Sdk/ResponseObject.h>


@class Fresh8AdView;

@protocol Fresh8AdViewDelegate

@optional
-(void)onFresh8AdViewStatus:(Fresh8AdView *)fresh8AdView andSuccessful:(BOOL)successful;

@end

@interface Fresh8AdView : UIView{

}
@property (nonatomic, strong) UIViewController *viewController;

@property(nonatomic, strong) NSString *identifier;
@property(nonatomic, strong) NSString *uniqueViewId;
@property (nonatomic, assign) id<Fresh8AdViewDelegate> delegate;
@property (nonatomic, strong) ResponseObject *responseObject;
-(void)setData:(ResponseObject *)responseObject andHtml:(NSString *)html;







@end
