//
//  Fresh8MobileAds.h
//  Fresh8Sdk
//
//  Created by Aram Pamuk on 12/11/2015.
//  Copyright © 2015 Aram Pamuk. All rights reserved.
//

#ifndef Fresh8MobileAds_h
#define Fresh8MobileAds_h


#endif /* Fresh8MobileAds_h */
