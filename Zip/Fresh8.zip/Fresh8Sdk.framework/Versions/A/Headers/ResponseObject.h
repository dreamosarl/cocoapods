//
//  ResponseObject.h
//  Fresh8Sdk
//
//  Created by Aram Pamuk on 30/10/2015.
//  Copyright © 2015 Aram Pamuk. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ResponseObject : NSObject

@property (nonatomic, strong) NSString *color;
@property (nonatomic, strong) NSString *cookiesDomain;
@property (nonatomic) bool existing;
@property (nonatomic, strong) NSString *fullScreenUrl;
@property (nonatomic, strong) NSString *host;
@property (nonatomic, strong) NSString *viewIdentifier;
@property (nonatomic, strong) NSMutableDictionary *slots;
@property (nonatomic, strong) NSString *html;
@property (nonatomic) bool interstitial;


- (instancetype)initWithDictionary:(NSDictionary *)dictionary;
- (instancetype)__unavailable init;
- (UIColor *)getUIColor;

@end
