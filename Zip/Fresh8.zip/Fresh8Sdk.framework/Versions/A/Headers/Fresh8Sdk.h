//
//  Fresh8Sdk.h
//  Fresh8Sdk
//
//  Created by Aram Pamuk on 29/10/2015.
//  Copyright © 2015 Aram Pamuk. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Fresh8Sdk/Fresh8Sdk.h>
#import <Fresh8Sdk/Fresh8AdView.h>
#import <Fresh8Sdk/ResponseObject.h>


#if __IPHONE_OS_VERSION_MIN_REQUIRED < __IPHONE_6_0
#error The Fresh 8 Mobile Ads SDK requires a deployment target of iOS 6.0 or later.
#endif


@interface Fresh8Sdk : NSObject<UIWebViewDelegate> {
    
    __strong NSMutableArray *providerCookies;
    __strong ResponseObject *responseObject;
    __strong NSString *instId;
}

@property (nonatomic) BOOL enableDebugLogging;
@property (nonatomic, strong) NSArray *favourites;
@property (nonatomic, strong) UIViewController *viewController;

- (instancetype)__unavailable init;
- (instancetype)initWithViewController:(UIViewController *)viewController andInstallationId:(NSString *)installationId;

-(void)presentAdBannerInContent:(NSArray *)content andViewIdentifier:(NSString *)viewIdentifier andFresh8AdView:(Fresh8AdView *)fresh8AdView;
-(void)presentAdBannerInMatchWithHomeTeam:(NSString *)homeTeam andAwayTeam:(NSString *)awayTeam andLeague:(NSString *)league andViewIdentifier:(NSString *)viewIdentifier andFresh8AdView:(Fresh8AdView *)fresh8AdView;

-(void)presentAdvertsInViewWithTags:(NSDictionary *)tags andViewIdentifier:(NSString *)viewIdentifier andFresh8AdViews:(Fresh8AdView *)fresh8AdViews, ... NS_REQUIRES_NIL_TERMINATION;

-(void)presentAdvertsInViewWithContent:(NSArray *)content andFullScreen:(BOOL)fullScreen andViewIdentifier:(NSString *)viewIdentifier andFresh8AdViews:(Fresh8AdView *)fresh8AdViews, ... NS_REQUIRES_NIL_TERMINATION;
-(void)presentAdvertsInMatchWithHomeTeam:(NSString *)homeTeam andAwayTeam:(NSString *)awayTeam andLeague:(NSString *)league andViewIdentifier:(NSString *)viewIdentifier andFresh8AdViews:(Fresh8AdView *)fresh8AdViews, ... NS_REQUIRES_NIL_TERMINATION;

@end
