//
//  IRSurveySession.h
//  IRSurveyLib
//
//  Created by Heiko Dreyer on 10/24/13.
//  Copyright (c) 2013 interrogare.de. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    IRSurveyLogLevelOff,
    IRSurveyLogLevelError,
    IRSurveyLogLevelInfo,
    IRSurveyLogLevelAll
} IRSurveyLogLevel;

///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////

@interface IRSurveySession : NSObject

///---------------------------------------------------------------------------------------
/// @name Access session properties
///---------------------------------------------------------------------------------------

/**
 Logging is deactivated by default. Info and/or error logging can be enabled optionally.
 */
@property (nonatomic, assign) IRSurveyLogLevel debugLogLevel;

/**
 Current app identifier.
 */
@property (readonly) NSString *appIdentifier;

///---------------------------------------------------------------------------------------
/// @name Lifecycle
///---------------------------------------------------------------------------------------

/**
 Returns a default instance.
 */
+ (IRSurveySession *)defaultSession;


///---------------------------------------------------------------------------------------
/// @name Manage current session
///---------------------------------------------------------------------------------------

/**
 Starts current session. Providing an `appIdentifier` is required.
 
 @param appIdentifier Identifies application.
 @return Success or no success.
 @warning `appIdentifier` shouldn't be `nil`.
 */
- (BOOL)startSessionWithAppIdentifier:(NSString *)appIdentifier;
 
/**
 Terminates current session. Cancels all internal processes.
 
 @return Return operation success
 */
- (BOOL)terminateSession;

@end
