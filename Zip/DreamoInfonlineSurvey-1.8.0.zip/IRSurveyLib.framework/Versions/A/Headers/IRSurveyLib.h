//
//  IRSurveyLib.h
//  IRSurveyLib
//
//  Created by Heiko Dreyer on 10/24/13.
//  Copyright (c) 2013 interrogare.de. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IRSurveyLib/IRSurveySession.h"