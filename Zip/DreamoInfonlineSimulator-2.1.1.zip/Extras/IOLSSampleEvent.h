//
//  IOLSSampleEvent.h
//  SwiftSample
//
//  Created by Robin Schmidt on 25.07.17.
//  Copyright © 2017 RockAByte GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "IOLSCustomParameterSectionModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface IOLSSampleEvent : NSObject

typedef NS_ENUM(NSUInteger, IOLSSampleEventKind) {
    IOLSSampleEventKindAccessory,
    IOLSSampleEventKindAdvertisement,
    IOLSSampleEventKindApplication,
    IOLSSampleEventKindAudio,
    IOLSSampleEventKindBackgroundTask,
    IOLSSampleEventKindData,
#if TARGET_OS_IOS
    IOLSSampleEventKindDeviceOrientation,
#endif
    IOLSSampleEventKindDocument,
    IOLSSampleEventKindDownload,
    IOLSSampleEventKindGame,
    IOLSSampleEventKindGesture,
    IOLSSampleEventKindHardwareButton,
    IOLSSampleEventKindIAP,
    IOLSSampleEventKindInternetConnection,
    IOLSSampleEventKindLogin,
    IOLSSampleEventKindOpenApp,
    IOLSSampleEventKindPush,
    IOLSSampleEventKindUpload,
    IOLSSampleEventKindVideo,
    IOLSSampleEventKindView,
    IOLSSampleEventKindWebView,
    IOLSSampleEventKindCustom
};

@property (nonatomic) IOLSSampleEventKind kind;
@property (nonatomic, copy) NSString *identifier;
@property (nonatomic, copy) NSArray<NSString*> *types;
@property (nonatomic) BOOL isAutomaticEvent;

@property (nonatomic) NSInteger selectedType;
@property (nonatomic, copy) NSString *selectedTypeName;
@property (nonatomic, copy) NSString *category;
@property (nonatomic, copy) NSString *comment;
@property (nonatomic, copy) NSDictionary<NSString*, NSString*> *parameters;

- (instancetype)initWithIdentifier:(NSString*)identifier kind:(IOLSSampleEventKind)kind types:(NSArray<NSString*>*)types isAutomatic:(BOOL)automatic;

- (void)addCustomParameter:(NSArray<IOLSCustomParameterSectionModel*>*)parameter;

- (void)clearCustomParameter;

+ (NSArray<IOLSSampleEvent*>*)generateSampleEvents;
@end

NS_ASSUME_NONNULL_END

