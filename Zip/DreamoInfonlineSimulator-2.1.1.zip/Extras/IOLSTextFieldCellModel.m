//
//  IOLSTextFieldCellModel.m
//  SwiftSample
//
//  Created by Robin Schmidt on 11.08.17.
//  Copyright © 2017 RockAByte GmbH. All rights reserved.
//

#import "IOLSTextFieldCellModel.h"

NS_ASSUME_NONNULL_BEGIN

@implementation IOLSTextFieldCellModel

- (instancetype)initWithPlaceholder:(NSString*)placeholder text:(NSString*)text {
    self = [super init];
    if (self) {
        self.placeholder = placeholder;
        self.text = text;
    }
    return self;
}

@end

NS_ASSUME_NONNULL_END
