//
//  IOLSSelectEventSectionModel.h
//  SwiftSample
//
//  Created by Konstantin Karras on 08.08.17.
//  Copyright © 2017 RockAByte GmbH. All rights reserved.
//

#import "IOLSSection.h"

NS_ASSUME_NONNULL_BEGIN

@interface IOLSSelectEventSectionModel : NSObject <IOLSSection>

@property (nonatomic, copy) NSString *eventDescription;
@property (nonatomic, copy) NSString *customEventDescription;
@property (nonatomic) CellType cellType;

- (instancetype)initWithEventDescription:(NSString*)description;

@end

NS_ASSUME_NONNULL_END
