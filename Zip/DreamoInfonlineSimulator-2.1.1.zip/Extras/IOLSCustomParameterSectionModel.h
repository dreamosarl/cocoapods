//
//  IOLSCustomParameterSectionModel.h
//  SwiftSample
//
//  Created by Konstantin Karras on 07.08.17.
//  Copyright © 2017 RockAByte GmbH. All rights reserved.
//

#import "IOLSSection.h"

NS_ASSUME_NONNULL_BEGIN

@interface IOLSCustomParameterSectionModel : NSObject <IOLSSection>

@property (nonatomic, copy) NSString *key;
@property (nonatomic, copy) NSString *value;

@end

NS_ASSUME_NONNULL_END
