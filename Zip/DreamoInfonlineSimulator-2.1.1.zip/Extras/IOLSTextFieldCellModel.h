//
//  IOLSTextFieldCellModel.h
//  ObjCSample
//
//  Created by Robin Schmidt on 11.08.17.
//  Copyright © 2017 RockAByte GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface IOLSTextFieldCellModel : NSObject

@property (nonatomic, copy) NSString *placeholder;
@property (nonatomic, copy) NSString *text;

- (instancetype)initWithPlaceholder:(NSString*)placeholder text:(NSString*)text;

@end

NS_ASSUME_NONNULL_END
