//
//  IOLSOptionalParameterSectionModel.m
//  SwiftSample
//
//  Created by Konstantin Karras on 08.08.17.
//  Copyright © 2017 RockAByte GmbH. All rights reserved.
//

#import "IOLSOptionalParameterSectionModel.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, TextType) {
    TextTypeCategory = 0,
    TextTypeComment
};

@implementation IOLSOptionalParameterSectionModel

- (nullable NSString*)titleForHeaderInSection {
    return NSLocalizedString(@"<OptionalParameterSectionTitle>", nil);
}

- (NSInteger)numberOfRowsInSection {
    return 2;
}

- (IOLSTextFieldCellModel*)textFieldCellModelForIndex:(NSUInteger)index {
    TextType type = index;
    switch (type) {
        case TextTypeCategory:
            return [[IOLSTextFieldCellModel alloc] initWithPlaceholder:NSLocalizedString(@"<OptionalParameterSectionCategoryPlaceholder>", nil) text:self.category];
        case TextTypeComment:
            return [[IOLSTextFieldCellModel alloc] initWithPlaceholder:NSLocalizedString(@"<OptionalParameterSectionCommentPlaceholder>", nil) text:self.comment];
    }
}

- (void)updateText:(NSString*)text atRow:(NSInteger)row {
    switch (row) {
        case TextTypeCategory:
            self.category = text;
            break;
        case TextTypeComment:
            self.comment = text;
            break;
        default:
            break;
    }
}

- (CellType)cellTypeForIndex:(NSInteger)index {
    return CellTypeTextField;
}

@end

NS_ASSUME_NONNULL_END
