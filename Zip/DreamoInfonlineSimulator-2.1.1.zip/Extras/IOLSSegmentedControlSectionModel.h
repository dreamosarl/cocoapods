//
//  IOLSSegmentedControlSectionModel.h
//  SwiftSample
//
//  Created by Konstantin Karras on 08.08.17.
//  Copyright © 2017 RockAByte GmbH. All rights reserved.
//

#import "IOLSSection.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, SegmentIndex) {
    SegmentIndexPredefined,
    SegmentIndexCustom
};

@interface IOLSSegmentedControlSectionModel : NSObject <IOLSSection>

@property (nonatomic) SegmentIndex segmentIndex;

+ (NSString*)titleForPredefinedSegment;

@end

NS_ASSUME_NONNULL_END
