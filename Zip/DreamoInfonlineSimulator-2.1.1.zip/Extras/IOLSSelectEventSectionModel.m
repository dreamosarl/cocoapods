//
//  IOLSSelectEventSectionModel.m
//  SwiftSample
//
//  Created by Konstantin Karras on 08.08.17.
//  Copyright © 2017 RockAByte GmbH. All rights reserved.
//

#import "IOLSSelectEventSectionModel.h"

NS_ASSUME_NONNULL_BEGIN

@implementation IOLSSelectEventSectionModel
@synthesize eventDescription = _eventDescription;

- (instancetype)initWithEventDescription:(NSString*)description {
    self = [super init];
    
    if (self) {
        self.eventDescription = description.copy;
        self.cellType = CellTypeSelectEvent;
    }
    return self;
}

- (nullable NSString*)titleForHeaderInSection {
    return NSLocalizedString(@"<SelectEventTitle>", nil);
}

- (NSInteger)numberOfRowsInSection {
    return 2;
}

- (IOLSTextFieldCellModel*)textFieldCellModelForIndex:(NSUInteger)index {
    switch (index) {
        case TextFieldCellTypeKey:
            return [[IOLSTextFieldCellModel alloc] initWithPlaceholder:NSLocalizedString(@"<SelectEventPlaceholder>", nil) text:self.customEventDescription];
        default:
            return [[IOLSTextFieldCellModel alloc] initWithPlaceholder:NSLocalizedString(@"<SelectEventPlaceholderUnknown>", nil) text:NSLocalizedString(@"<SelectEventUnknownEventDescription>", nil)];
    }
}

- (void)updateText:(NSString*)text atRow:(NSInteger)row {
    switch (row) {
        case TextFieldCellTypeKey:
            self.customEventDescription = text;
            break;
        default:
            break;
    }
}


- (void)setEventDescription:(NSString*)eventDescription {
    _eventDescription = eventDescription;
}

- (NSString*)eventDescription {
    return _eventDescription.length > 0 ? _eventDescription : [self titleForHeaderInSection];
}


- (CellType)cellTypeForIndex:(NSInteger)index {
    switch (index) {
        case TextFieldCellTypeKey:
            return self.cellType;
        default:
            return CellTypeAddCustomParameter;
    }
}

@end

NS_ASSUME_NONNULL_END
