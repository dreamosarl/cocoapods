//
//  IOLSSection.h
//  SwiftSample
//
//  Created by Konstantin Karras on 08.08.17.
//  Copyright © 2017 RockAByte GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "IOLSTextFieldCellModel.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, CellType) {
    CellTypeSegmentedControl,
    CellTypeSelectEvent,
    CellTypeTextField,
    CellTypeSelectParameterKey,
    CellTypeAddCustomParameter
};

typedef NS_ENUM(NSUInteger, TextFieldCellType) {
    TextFieldCellTypeKey = 0,
    TextFieldCellTypeValue
};

@protocol IOLSSection <NSObject>

- (nullable NSString*)titleForHeaderInSection;
- (NSInteger)numberOfRowsInSection;
- (CellType)cellTypeForIndex:(NSInteger)index;

@optional

- (void)updateText:(NSString*)text atRow:(NSInteger)row;
- (IOLSTextFieldCellModel*)textFieldCellModelForIndex:(NSUInteger)index;

@end

NS_ASSUME_NONNULL_END
