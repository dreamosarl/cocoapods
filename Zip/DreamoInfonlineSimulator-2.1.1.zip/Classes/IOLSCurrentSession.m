//
//  IOLSCurrentSession.m
//  ObjCSample
//
//  Created by Konstantin Karras on 17.08.17.
//  Copyright © 2017 RockAByte GmbH. All rights reserved.
//

#import "IOLSCurrentSession.h"

NS_ASSUME_NONNULL_BEGIN

NSString * const IOLSCurrentSessionDidSwitchNotification = @"IOLSCurrentSessionDidSwitchNotification";

@implementation IOLSCurrentSession

+ (instancetype)sharedInstance {
    static dispatch_once_t onceToken;
    static IOLSCurrentSession *sSharedInstance;
    
    dispatch_once(&onceToken, ^{
        if (!sSharedInstance) {
            sSharedInstance = [IOLSCurrentSession new];
        }
    });
    return sSharedInstance;
}

- (void)setSessionType:(IOLSessionType)sessionType {
    if (_sessionType != sessionType) {
        _sessionType = sessionType;
        [NSNotificationCenter.defaultCenter postNotificationName:IOLSCurrentSessionDidSwitchNotification object:nil];
    }
}

@end

NS_ASSUME_NONNULL_END
