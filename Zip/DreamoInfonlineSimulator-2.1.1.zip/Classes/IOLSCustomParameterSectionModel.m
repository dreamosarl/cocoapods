//
//  IOLSCustomParameterSectionModel.m
//  SwiftSample
//
//  Created by Konstantin Karras on 07.08.17.
//  Copyright © 2017 RockAByte GmbH. All rights reserved.
//

#import "IOLSCustomParameterSectionModel.h"

NS_ASSUME_NONNULL_BEGIN

@implementation IOLSCustomParameterSectionModel

- (nullable NSString*)titleForHeaderInSection {
    return NSLocalizedString(@"<CustomParameterTitle>", nil);
}

- (NSInteger)numberOfRowsInSection {
    return 2;
}

- (IOLSTextFieldCellModel*)textFieldCellModelForIndex:(NSUInteger)index {
    TextFieldCellType type = index;
    switch (type) {
        case TextFieldCellTypeKey:
            return [[IOLSTextFieldCellModel alloc] initWithPlaceholder:NSLocalizedString(@"<CustomParameterKeyPlaceholder>", nil) text:self.key];
        case TextFieldCellTypeValue:
            return [[IOLSTextFieldCellModel alloc] initWithPlaceholder:NSLocalizedString(@"<CustomParameterValuePlaceholder>", nil) text:self.value];
    }
}

- (void)updateText:(NSString*)text atRow:(NSInteger)row {
    switch (row) {
        case TextFieldCellTypeKey:
            self.key = text;
            break;
        case TextFieldCellTypeValue:
            self.value = text;
            break;
    }
}

- (CellType)cellTypeForIndex:(NSInteger)index {
    switch (index) {
        case TextFieldCellTypeKey:
            return CellTypeSelectParameterKey;
        default:
            return CellTypeTextField;
    }
}

@end

NS_ASSUME_NONNULL_END
