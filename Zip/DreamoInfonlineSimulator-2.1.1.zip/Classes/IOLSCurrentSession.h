//
//  IOLSCurrentSession.h
//  SwiftSample
//
//  Created by Konstantin Karras on 17.08.17.
//  Copyright © 2017 RockAByte GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <INFOnlineLibrary/INFOnlineLibrary.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString * const IOLSCurrentSessionDidSwitchNotification;

@interface IOLSCurrentSession : NSObject

@property (nonatomic, copy) NSString *customerData;
@property (nonatomic) IOLSessionType sessionType;
@property (nonatomic) IOLPrivacyType privacyType;

+ (instancetype)sharedInstance;

@end

NS_ASSUME_NONNULL_END
