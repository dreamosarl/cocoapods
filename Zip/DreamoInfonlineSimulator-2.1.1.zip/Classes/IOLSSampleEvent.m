//
//  IOLSSampleEvent.m
//  SwiftSample
//
//  Created by Robin Schmidt on 25.07.17.
//  Copyright © 2017 RockAByte GmbH. All rights reserved.
//

#import "IOLSSampleEvent.h"

#import <UIKit/UIKit.h>

#import "IOLSCurrentSession.h"
#import "IOLSConstants.h"

NS_ASSUME_NONNULL_BEGIN

@interface IOLSSampleEvent ()

@end

@implementation IOLSSampleEvent

- (instancetype)initWithIdentifier:(NSString*)identifier kind:(IOLSSampleEventKind)kind types:(NSArray<NSString*>*)types isAutomatic:(BOOL)automatic {
    self = [super init];
    
    if (self) {
        _identifier = identifier;
        _kind = kind;
        _types = types;
        _isAutomaticEvent = automatic;
    }
    return self;
}

- (void)setSelectedType:(NSInteger)selectedType {
    _selectedType = selectedType;
    _selectedTypeName = _types[_selectedType];
}

- (NSString*)description {
    return [_identifier stringByAppendingFormat:@".%@", _selectedTypeName];
}

- (void)addCustomParameter:(NSArray<IOLSCustomParameterSectionModel*>*)parameter {
    if (parameter.count < 1 ) return;
    NSMutableDictionary<NSString*, NSString*> *mutableParameter = [NSMutableDictionary<NSString*, NSString*> new];
    [parameter enumerateObjectsUsingBlock:^(IOLSCustomParameterSectionModel * _Nonnull customParameter, NSUInteger idx, BOOL * _Nonnull stop) {
        [mutableParameter setObject:customParameter.value forKey:customParameter.key];
    }];
    self.parameters = mutableParameter.copy;
}

- (void)clearCustomParameter {
    self.parameters = [NSDictionary new];
}

+ (NSArray<IOLSSampleEvent*>*)generateSampleEvents {
    if ([IOLSCurrentSession sharedInstance].sessionType == IOLSessionTypeOEWA) {
        return [self generateOEWASampleEvents];
    } else {
        return [self generateSZMSampleEvents];
    }
}

+ (NSArray<IOLSSampleEvent*>*)generateOEWASampleEvents {
    return @[[[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierView kind:IOLSSampleEventKindView
                                                   types:@[@"appeared"] isAutomatic:NO]];
}

+ (NSArray<IOLSSampleEvent*>*)generateSZMSampleEvents {
    return @[[[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierAccessory kind:IOLSSampleEventKindAccessory
                                                   types:@[@"connected", @"disconnected"] isAutomatic:YES],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierAdvertisement kind:IOLSSampleEventKindAdvertisement
                                                   types:@[@"open", @"close"] isAutomatic:NO],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierApplication kind:IOLSSampleEventKindApplication
                                                   types:@[@"start", @"enterBackground", @"enterForeground", @"resignActive", @"becomeActive", @"terminate", @"crashed"] isAutomatic:YES],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierAudio kind:IOLSSampleEventKindAudio
                                                   types:@[@"play", @"pause", @"stop", @"next", @"previous"] isAutomatic:NO],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierBackgroundTask kind:IOLSSampleEventKindBackgroundTask
                                                   types:@[@"start", @"end"] isAutomatic:NO],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierData kind:IOLSSampleEventKindData
                                                   types:@[@"cancelled", @"start", @"succeeded", @"failed"] isAutomatic:NO],
#if TARGET_OS_IOS
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierDeviceOrientation kind:IOLSSampleEventKindDeviceOrientation
                                                   types:@[@"changed"] isAutomatic:NO],
#endif
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierDocument kind:IOLSSampleEventKindDocument
                                                   types:@[@"open", @"edit", @"close"] isAutomatic:NO],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierDownload kind:IOLSSampleEventKindDownload
                                                   types:@[@"cancelled", @"start", @"succeeded", @"failed"] isAutomatic:NO],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierGame kind:IOLSSampleEventKindGame
                                                   types:@[@"action", @"started", @"finished", @"won", @"lost", @"highscore", @"achievement"] isAutomatic:NO],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierGesture kind:IOLSSampleEventKindGesture
                                                   types:@[@"shake"] isAutomatic:NO],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierHardwareButton kind:IOLSSampleEventKindHardwareButton
                                                   types:@[@"pushed"] isAutomatic:NO],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierIAP kind:IOLSSampleEventKindIAP
                                                   types:@[@"started", @"finished", @"cancelled"] isAutomatic:NO],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierInternetConnection kind:IOLSSampleEventKindInternetConnection
                                                   types:@[@"established", @"lost", @"switchedInterface"] isAutomatic:YES],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierLogin kind:IOLSSampleEventKindLogin
                                                   types:@[@"succeeded", @"failed", @"logout"] isAutomatic:NO],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierOpenApp kind:IOLSSampleEventKindOpenApp
                                                   types:@[@"maps", @"other"] isAutomatic:NO],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierPush kind:IOLSSampleEventKindPush
                                                   types:@[@"received"] isAutomatic:NO],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierUpload kind:IOLSSampleEventKindUpload
                                                   types:@[@"cancelled", @"start", @"succeeded", @"failed"] isAutomatic:NO],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierVideo kind:IOLSSampleEventKindVideo
                                                   types:@[@"play", @"pause", @"stop", @"next", @"previous", @"replay", @"seekBack", @"seekForeward"] isAutomatic:NO],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierView kind:IOLSSampleEventKindView
                                                   types:@[@"appeared", @"refreshed", @"disappeared"] isAutomatic:NO],
             [[IOLSSampleEvent alloc] initWithIdentifier:IOLSEventIdentifierWebView kind:IOLSSampleEventKindWebView types:@[@"init"] isAutomatic:YES]];
}

@end

NS_ASSUME_NONNULL_END
