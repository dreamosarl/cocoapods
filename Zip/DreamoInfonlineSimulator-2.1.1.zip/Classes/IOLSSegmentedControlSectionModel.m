//
//  IOLSSegmentedControlSectionModel.m
//  SwiftSample
//
//  Created by Konstantin Karras on 08.08.17.
//  Copyright © 2017 RockAByte GmbH. All rights reserved.
//

#import "IOLSSegmentedControlSectionModel.h"

#import "IOLSCurrentSession.h"
#import "IOLSSessionHelper.h"

NS_ASSUME_NONNULL_BEGIN

@implementation IOLSSegmentedControlSectionModel

- (nullable NSString*)titleForHeaderInSection {
    return nil;
}

- (NSInteger)numberOfRowsInSection {
    return 1;
}

- (CellType)cellTypeForIndex:(NSInteger)index {
    return CellTypeSegmentedControl;
}

+ (NSString*)titleForPredefinedSegment {
    return NSLocalizedString( [IOLSSessionHelper sessionLocaString:[IOLSCurrentSession sharedInstance].sessionType], nil);
}

@end

NS_ASSUME_NONNULL_END
