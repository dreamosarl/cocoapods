//
//  IAInterfaceAdDescription.h
//  IASDKCore
//
//  Created by Inneractive on 27/04/2017.
//  Copyright © 2017 Inneractive. All rights reserved.
//

#ifndef IAInterfaceAdDescription_h
#define IAInterfaceAdDescription_h

#import <Foundation/Foundation.h>

@protocol IAInterfaceAdDescription <NSObject>

@required

@end

#endif /* IAInterfaceAdDescription_h */
