//
//  IAContentController.h
//  IASDKCore
//
//  Created by Inneractive on 19/03/2017.
//  Copyright © 2017 Inneractive. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  @brief  Abstract base class.
 */
@interface IAContentController : NSObject

@end
