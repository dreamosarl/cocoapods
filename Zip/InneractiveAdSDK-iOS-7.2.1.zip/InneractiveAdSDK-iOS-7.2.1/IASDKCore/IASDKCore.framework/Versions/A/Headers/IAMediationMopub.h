//
//  IAMediationMopub.h
//  IASDKCore
//
//  Created by Inneractive on 20/03/2017.
//  Copyright © 2017 Inneractive. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "IAMediation.h"

@interface IAMediationMopub : IAMediation

@end
