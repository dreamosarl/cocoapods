//
//  IAInterfaceContentModel.h
//  IASDKCore
//
//  Created by Inneractive on 27/03/2017.
//  Copyright © 2017 Inneractive. All rights reserved.
//

#ifndef IAInterfaceContentModel_h
#define IAInterfaceContentModel_h

#import <Foundation/Foundation.h>

@protocol IAInterfaceContentModel  <NSObject>

@required

@end

#endif /* IAInterfaceContentModel_h */
