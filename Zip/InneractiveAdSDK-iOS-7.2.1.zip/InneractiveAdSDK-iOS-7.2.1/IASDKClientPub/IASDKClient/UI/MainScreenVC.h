//
//  MainScreenVC.h
//  IASDKClient
//
//  Created by Inneractive on 15/02/2017.
//  Copyright © 2017 Inneractive. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainScreenVC : UITableViewController

@end
