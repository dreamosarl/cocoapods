//
//  IAColors.h
//  IASDKClient
//
//  Created by Inneractive on 06/04/2017.
//  Copyright (c) 2017 Inneractive. All rights reserved.
//

#import <Foundation/Foundation.h>

#define kIAColorsNavigationBar [UIColor whiteColor]
#define kIAColorsButtonsText [UIColor colorWithRed:255/255.0 green:151/255.0 blue:4/255.0 alpha:1.0]
#define kIAColorsAquamarine [UIColor colorWithRed:36/255.0 green:183/255.0 blue:197/255.0 alpha:1.0]
