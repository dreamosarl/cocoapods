//
//  IANativeAdTwoUnitsTableVС.h
//  IASDKClient
//
//  Created by Inneractive on 09/03/2017.
//  Copyright (c) 2017 Inneractive. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  @brief Story example in table view with 2 different ad unit.
 */
@interface IANativeAdTwoUnitsTableVС : UIViewController

@end
