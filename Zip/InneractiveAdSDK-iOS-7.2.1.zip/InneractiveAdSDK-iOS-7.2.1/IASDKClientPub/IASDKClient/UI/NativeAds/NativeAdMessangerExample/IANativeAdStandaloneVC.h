//
//  IANativeAdStandaloneVC.h
//  IASDKClient
//
//  Created by Inneractive on 09/03/2017.
//  Copyright (c) 2017 Inneractive. All rights reserved.
//

#import "IAMessageTextField.h"

/**
 * Native Ad example
 */
@interface IANativeAdStandaloneVC : UIViewController <UITableViewDataSource, UITableViewDelegate, IAMessageTextFieldDelegate>

@end
