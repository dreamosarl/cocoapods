//
//  MoatMobileAppKit.h
//  MoatMobileAppKit
//
//  Created by Moat on 12/31/14.
//  Copyright © 2016 Moat. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "InaMoatAnalytics.h"

@interface InaMoatMobileAppKit : NSObject

@end
